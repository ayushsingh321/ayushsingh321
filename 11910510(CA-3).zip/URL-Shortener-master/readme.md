A live demo of the finished product can be viewed here:

[http://laracasts-url.eu1.frbit.net/](http://laracasts-url.eu1.frbit.net/)
