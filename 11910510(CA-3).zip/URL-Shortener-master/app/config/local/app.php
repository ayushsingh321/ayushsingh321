<?php

return [
    'debug' => true
];