<?php namespace Way\Exceptions;

class NonExistentHashException extends \Exception {};
