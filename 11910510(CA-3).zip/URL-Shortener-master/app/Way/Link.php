<?php namespace Way;

class Link extends \Eloquent {

    /**
     * Fillable fields
     *
     * @var array
     */
    protected $fillable = ['url', 'hash'];

}
